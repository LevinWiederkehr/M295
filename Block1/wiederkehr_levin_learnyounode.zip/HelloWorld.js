const Addiere = (a, b) => {
    return a + b;
}

console.log("Hello World!");

let summe = Addiere(5, 10);
console.log("Die Summe ist: " + summe);